# Placeholder for utility functions (e.g., reranker, prompt templating)
def format_prompt(query, contexts):
    header = "You are an expert assistant. Use the contexts below to answer the question concisely."
    prompt = header + "\n\nCONTEXTS:\n"
    for i,c in enumerate(contexts):
        prompt += f"Context {i+1}: " + c["text"] + "\n\n"
    prompt += "\nQUESTION: " + query + "\n\nAnswer:"
    return prompt