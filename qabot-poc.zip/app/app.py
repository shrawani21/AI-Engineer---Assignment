from fastapi import FastAPI, Query
from fastapi.responses import JSONResponse
import os, json, numpy as np
from sentence_transformers import SentenceTransformer
import faiss

app = FastAPI(title="RAG Q&A PoC")

# Load model and index at startup
MODEL_NAME = os.environ.get("EMBED_MODEL", "all-MiniLM-L6-v2")
EMBEDDING_MODEL = SentenceTransformer(MODEL_NAME)
INDEX_DIR = os.environ.get("INDEX_DIR", "data/index")
INDEX_PATH = os.path.join(INDEX_DIR, "index.faiss")
CHUNKS_PATH = os.path.join(INDEX_DIR, "chunks.json")

if os.path.exists(INDEX_PATH) and os.path.exists(CHUNKS_PATH):
    index = faiss.read_index(INDEX_PATH)
    with open(CHUNKS_PATH, "r", encoding="utf-8") as f:
        CHUNKS = json.load(f)
    DIM = EMBEDDING_MODEL.get_sentence_embedding_dimension()
else:
    index = None
    CHUNKS = []

def retrieve(query: str, top_k: int=3):
    if index is None:
        return []
    q_emb = EMBEDDING_MODEL.encode([query], convert_to_numpy=True)
    faiss.normalize_L2(q_emb)
    D, I = index.search(q_emb, top_k)
    results = []
    for sid, score in zip(I[0], D[0]):
        if sid < 0 or sid >= len(CHUNKS):
            continue
        results.append({"id": CHUNKS[sid]["id"], "text": CHUNKS[sid]["text"], "score": float(score)})
    return results

@app.get("/ask")
def ask(query: str = Query(..., min_length=1)):
    if index is None:
        return JSONResponse({"error":"Index not built. Run scripts/build_index.py first."}, status_code=400)
    results = retrieve(query, top_k=3)
    # Simple concatenation of top contexts; in production use prompt template and LLM call
    context = "\n\n".join([r["text"] for r in results])
    answer = {
        "query": query,
        "contexts": results,
        "generated_answer": f"Use retrieved contexts to answer: {context[:500]}"
    }
    return JSONResponse(answer)