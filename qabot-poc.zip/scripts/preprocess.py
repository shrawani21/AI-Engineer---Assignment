#!/usr/bin/env python3
import argparse, json, os, math
from typing import List
from pypdf import PdfReader

def extract_text_from_pdf(path: str) -> str:
    reader = PdfReader(path)
    texts = []
    for page in reader.pages:
        texts.append(page.extract_text() or "")
    return "\n".join(texts)

def chunk_text(text: str, chunk_size: int=400, overlap: int=100) -> List[dict]:
    words = text.split()
    chunks = []
    i = 0
    idx = 0
    while i < len(words):
        chunk_words = words[i:i+chunk_size]
        chunk_text = " ".join(chunk_words)
        chunks.append({"id": f"chunk_{idx}", "text": chunk_text})
        idx += 1
        i += chunk_size - overlap
    return chunks

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Input PDF or txt file")
    parser.add_argument("--out", required=True, help="Output JSON file for chunks")
    parser.add_argument("--chunk_size", type=int, default=400)
    parser.add_argument("--overlap", type=int, default=100)
    args = parser.parse_args()

    if not os.path.exists(args.input):
        raise SystemExit("Input file not found: " + args.input)
    if args.input.lower().endswith(".pdf"):
        text = extract_text_from_pdf(args.input)
    else:
        with open(args.input, "r", encoding="utf-8") as f:
            text = f.read()
    chunks = chunk_text(text, chunk_size=args.chunk_size, overlap=args.overlap)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(chunks, f, ensure_ascii=False, indent=2)
    print(f"Wrote {len(chunks)} chunks to {args.out}")

if __name__ == "__main__":
    main()